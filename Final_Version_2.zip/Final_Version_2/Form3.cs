﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Connection
{
     public partial class Form3 : Form
     {
          public Form3()
          {
               InitializeComponent();
               load_table();//Load table function
                string temp = Form1.variable1;//Storing student info
                label1.Text = temp;
                load_labels();//Shows student info at the top of the page 
        }
        void load_labels()
        {
            string constring = "datasource=localhost;Database=software_eng;Uid=root;Pwd=Junior11!;";
            MySqlConnection conDatabase = new MySqlConnection(constring);
            conDatabase.Open();
            string temp = Form1.variable1;
            MySqlCommand cmdDataBase = new MySqlCommand("select first_name, last_name from students_tbl where UserName = @UserName;", conDatabase);
            cmdDataBase.Parameters.Add(new MySqlParameter("UserName", temp));
            MySqlDataReader dr = cmdDataBase.ExecuteReader();
            if (dr.Read())
            {

                label2.Text = (dr["first_name"].ToString());
                label3.Text = (dr["last_name"].ToString());
            }
        }
        void load_table()//Loads table with data from database
          {
            string constring = "datasource=localhost;Database=software_eng;Uid=root;Pwd=Junior11!;";//Connection string, **CHANGE PASSWORD
            MySqlConnection conDatabase = new MySqlConnection(constring);//Initializing MySQLconnection with constring
            string temp = Form1.variable1;//Initializing string that will hold student info at the top of the page

            //SQL command is sent to MYSQL database using MySqlComman function , calls data from grades_tbl and course_tbl 
            MySqlCommand cmdDataBase = new MySqlCommand("SELECT UserName,course_number, course_name, start_time, end_time, days FROM grades_tbl a, courses_tbl b WHERE a.UserName = @UserName AND a.course_id = b.course_id; ; ", conDatabase);
            cmdDataBase.Parameters.Add(new MySqlParameter("UserName", temp));//Parameters added to MySql command
            try//loads table
            {

                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView1.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

          private void button1_Click(object sender, EventArgs e)
          {
            string constring = "datasource=localhost;Database=software_eng;Uid=root;Pwd=Junior11!;";//Constring **Change Password here
            MySqlConnection conDatabase = new MySqlConnection(constring);//MySql connection connected to database
            string temp = Form1.variable1;//String initialized that holds student info that will be displayed at the top of the page

            //SQL command sent to database using MySqlCommand
            MySqlCommand cmdDataBase = new MySqlCommand("SELECT avg(a.credits) AS GPA FROM grades_tbl a, courses_tbl b WHERE a.UserName = @UserName AND a.course_id = b.course_id;", conDatabase);
            cmdDataBase.Parameters.Add(new MySqlParameter("UserName", temp));
            try
            {

                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView1.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
          {
               string constring = "datasource=localhost;Database=software_eng;Uid=root;Pwd=Junior11!;";//**CHANGE PASSWORD HERE
               MySqlConnection conDatabase = new MySqlConnection(constring);//Database connected
               string temp = Form1.variable1;//Student info that will be displayed on the top of the page

               //Command sent to database using MySqlCommand
               MySqlCommand cmdDataBase = new MySqlCommand("SELECT course_number, course_name, start_time, end_time, days FROM grades_tbl a, courses_tbl b WHERE a.UserName = @UserName AND a.course_id = b.course_id; ; ", conDatabase);
               cmdDataBase.Parameters.Add(new MySqlParameter("UserName", temp));
               try//Table loaded using sql command
               {

                    MySqlDataAdapter sda = new MySqlDataAdapter();
                    sda.SelectCommand = cmdDataBase;
                    DataTable dbdataset = new DataTable();
                    sda.Fill(dbdataset);
                    BindingSource bSource = new BindingSource();

                    bSource.DataSource = dbdataset;
                    dataGridView1.DataSource = bSource;
                    sda.Update(dbdataset);
               }
               catch (Exception ex)
               {
                    MessageBox.Show(ex.Message);
               }
          }

        private void button3_Click(object sender, EventArgs e)
        {
            string constring = "datasource=localhost;Database=software_eng;Uid=root;Pwd=Junior11!;";//Change PASSWORD here
            MySqlConnection conDatabase = new MySqlConnection(constring);//Connection to database initialized
            string temp = Form1.variable1;//Student info stored that will be displayed on the top of the form

            //MySQL command sent to database using MySql command function
            MySqlCommand cmdDataBase = new MySqlCommand("SELECT course_number, course_name, exam_1, exam_2, final, final_grade FROM grades_tbl a, courses_tbl b WHERE a.UserName = @UserName AND a.course_id = b.course_id; ; ", conDatabase);
            cmdDataBase.Parameters.Add(new MySqlParameter("UserName", temp));
            try//load table function 
            {

                MySqlDataAdapter sda = new MySqlDataAdapter();
                sda.SelectCommand = cmdDataBase;
                DataTable dbdataset = new DataTable();
                sda.Fill(dbdataset);
                BindingSource bSource = new BindingSource();

                bSource.DataSource = dbdataset;
                dataGridView1.DataSource = bSource;
                sda.Update(dbdataset);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
